"""Phase 2 delay-risk model (ADR 0008): curve maths, learning a planted pattern, outputs and the risk API."""

import json
from datetime import timedelta
from pathlib import Path

import duckdb
import numpy as np
import pytest
from fastapi.testclient import TestClient

from app.ml import delay_risk as dr
from tests.ops_fixture import F1, write_ops

CURVE = [0.8, 0.6, 0.4, 0.2, 0.05, 0.01]  # P(delay >= 5, 15, 30, 60, 120, 180)


def test_survival_interpolates_between_thresholds() -> None:
    assert dr.survival(CURVE, 0) == 0.8
    assert dr.survival(CURVE, 15) == pytest.approx(0.6)
    assert dr.survival(CURVE, 45) == pytest.approx(0.3)
    assert dr.survival(CURVE, 300) < 0.01


def test_auc_and_brier_match_textbook_values() -> None:
    y = np.array([0, 0, 1, 1])
    assert dr.auc(y, np.array([0.1, 0.4, 0.35, 0.8])) == pytest.approx(0.75)
    assert dr.auc(y, np.array([0.5, 0.5, 0.5, 0.5])) == pytest.approx(0.5)
    assert dr.brier(y, np.array([0.0, 0.0, 1.0, 1.0])) == 0.0


def test_confusion_matrix_counts_and_rates() -> None:
    y = np.array([1, 1, 1, 0, 0, 0, 0, 0])
    p = np.array([0.9, 0.6, 0.2, 0.7, 0.3, 0.1, 0.1, 0.05])
    m = dr.confusion(y, p, 0.5)
    assert (m["true_positive"], m["false_positive"], m["false_negative"], m["true_negative"]) == (2, 1, 1, 4)
    assert m["precision"] == pytest.approx(2 / 3, abs=1e-4)
    assert m["recall"] == pytest.approx(2 / 3, abs=1e-4)
    assert m["f1"] == pytest.approx(2 / 3, abs=1e-4)
    assert m["accuracy"] == 0.75
    assert m["specificity"] == 0.8
    assert dr.confusion(y, p, 0.99)["precision"] is None  # nothing flagged
    top = dr._top_share(y, p, share=0.25)  # the 2 riskiest flights: one late, one not
    assert (top["flights"], top["late_rate"], top["lift"]) == (2, 0.5, round(0.5 / 0.375, 2))


def test_planning_delay_is_exceeded_with_20_percent_chance() -> None:
    assert dr.planning_delay(CURVE) == 60
    assert dr.planning_delay([0.1, 0.05, 0.02, 0.01, 0.0, 0.0]) is None
    assert dr.planning_delay([1, 1, 1, 1, 1, 0.9]) == 180


def test_miss_probability_grows_as_slack_shrinks_and_onward_delay_helps() -> None:
    on_time = [0.0] * 6
    tight, loose = dr.miss_probability(CURVE, on_time, 10), dr.miss_probability(CURVE, on_time, 100)
    assert tight > loose > 0
    assert dr.miss_probability(CURVE, CURVE, 10) < tight  # a late onward flight saves some connections
    assert dr.miss_probability(on_time, on_time, -5) == 1.0  # below MCT and nobody late: missed by the rule


@pytest.fixture(scope="module")
def ops(tmp_path_factory: pytest.TempPathFactory) -> Path:
    path = write_ops(tmp_path_factory.mktemp("risk"))
    dr.run(path, default_mct=50)
    return path


def test_model_learns_the_planted_pattern_and_writes_outputs(ops: Path) -> None:
    con = duckdb.connect()
    p60 = dict(con.execute(f"SELECT flight_id, p_60 FROM '{ops}/flight_risk.parquet'").fetchall())
    assert p60[F1] > 0.4  # KHI-SHJ morning: late 60+ on 70% of history days
    assert p60["G9101_202611210600"] < 0.15  # DOH-SHJ: almost never late
    card = json.loads((ops / "model_card.json").read_text())
    assert card["evaluation"]["metrics_by_threshold"]["60"]["auc"] > 0.8
    assert card["evaluation"]["connection_backtest"]
    classification = card["evaluation"]["classification"]
    assert set(classification) == {"departure_15", "departure_60", "arrival_15", "arrival_60"}
    high = classification["departure_60"]["operating_points"][0]
    tested = sum(high[k] for k in ("true_positive", "false_positive", "false_negative", "true_negative"))
    assert tested == int(card["evaluation"]["test"].split("(")[1].split()[0])
    assert len(classification["departure_15"]["sweep"]) == len(dr.SWEEP_CUTOFFS)
    rolling = card["evaluation"]["rolling_monthly"]
    assert rolling
    assert all("15" in fold and "60" in fold for fold in rolling)
    row = con.execute(f"SELECT reasons FROM '{ops}/flight_risk.parquet' WHERE flight_id = ?", [F1]).fetchone()
    assert row is not None
    reasons = json.loads(row[0])
    assert reasons
    assert all(r["contribution"] > 0 for r in reasons)
    conn = con.execute(
        f"""SELECT count(*), min(misconnect_risk), max(misconnect_risk), bool_and(NOT default_mct)
            FROM '{ops}/connection_risk.parquet' WHERE inbound_flight_id = ?""",
        [F1],
    ).fetchone()
    assert conn is not None
    assert conn[0] > 0
    assert 0 <= conn[1] <= conn[2] <= 1
    assert conn[3]  # KHI/SHJ/CAI has an MCT rule in the fixture


def test_training_is_deterministic(ops: Path, tmp_path: Path) -> None:
    again = write_ops(tmp_path)
    dr.run(again, default_mct=50)
    first = duckdb.connect().execute(f"SELECT * FROM '{ops}/flight_risk.parquet' ORDER BY flight_id").fetchall()
    second = duckdb.connect().execute(f"SELECT * FROM '{again}/flight_risk.parquet' ORDER BY flight_id").fetchall()
    assert first == second


def test_last_week_replays_unseen_flights_and_matches_the_actuals(ops: Path) -> None:
    week = json.loads((ops / "last_week.json").read_text())
    con = duckdb.connect()
    latest = con.execute(
        f"SELECT max(std) FROM '{ops}/history_flights.parquet' WHERE operated AND NOT coalesce(diverted, FALSE)"
    ).fetchone()
    assert latest is not None
    end = latest[0]
    start = end - timedelta(days=dr.LAST_WEEK_DAYS)
    counts = con.execute(
        f"""SELECT count(*), count(*) FILTER (WHERE date_diff('minute', std, atd) >= 60)
            FROM '{ops}/history_flights.parquet'
            WHERE operated AND NOT coalesce(diverted, FALSE) AND std >= ?""",
        [start],
    ).fetchone()
    assert counts is not None
    n, late = counts
    assert week["flights"] == n  # every flight of the week, no more
    flag = week["flag_60"]
    assert flag["true_positive"] + flag["false_negative"] == late  # the real 60+ minute delays, all accounted for
    assert sum(flag[k] for k in ("true_positive", "false_positive", "false_negative", "true_negative")) == n
    assert week["rows_total"] == flag["true_positive"] + flag["false_positive"] + flag["false_negative"]
    assert {r["outcome"] for r in week["rows"]} <= {"hit", "false_alarm", "missed"}
    assert all((r["band"] == "low") == (r["outcome"] == "missed") for r in week["rows"])


def test_watchlist_and_flight_risk_api(
    client: TestClient, auth: dict[str, str], evaluator_auth: dict[str, str]
) -> None:
    body = client.get("/api/v1/risk/watchlist?band=all&sort=delay", headers=auth).json()
    assert body["flights"]
    p60 = [f["p_60"] for f in body["flights"]]
    assert p60 == sorted(p60, reverse=True)
    assert F1 in {f["flight_id"] for f in body["flights"]}
    assert body["totals"]["flights"] == len(body["flights"])
    detail = client.get(f"/api/v1/risk/flights/{F1}", headers=auth).json()
    assert detail["flight"]["reasons"]
    assert detail["connections"]
    assert "pnr" in detail["connections"][0]
    assert "name" not in detail["connections"][0]
    assert client.get("/api/v1/risk/model", headers=evaluator_auth).json()["thresholds_minutes"] == list(dr.THRESHOLDS)
    assert client.get("/api/v1/risk/flights/G9999_202611210000", headers=auth).status_code == 404
    assert client.get("/api/v1/risk/flights/bad id", headers=auth).status_code == 422
    assert client.get("/api/v1/risk/watchlist").status_code == 401
    week = client.get("/api/v1/risk/last-week", headers=auth).json()
    assert week["flights"] > 0
    assert "flag_60" in week
    assert client.get("/api/v1/risk/last-week").status_code == 401


def test_live_models_are_written_and_scored(ops: Path) -> None:
    for kind in ("dep", "arr_in", "arr_dep"):
        for t in dr.THRESHOLDS:
            assert (ops / "live_models" / f"{kind}_{t}.txt").exists()
    card = json.loads((ops / "live_model_card.json").read_text())
    assert {"dep", "arr_in", "arr_dep"} <= card.keys()
    assert card["arr_dep"]["60"]["auc"] >= card["arr_dep"]["60"]["planning_auc"]


def test_predict_api_planning_and_live(client: TestClient, auth: dict[str, str]) -> None:
    url = f"/api/v1/risk/flights/{F1}/predict"
    planning = client.post(url, json={}, headers=auth).json()
    assert planning["departure"]["mode"] == planning["arrival"]["mode"] == "planning"
    assert set(planning["departure"]["p"]) == {"5", "15", "30", "60", "120", "180"}
    late = client.post(url, json={"departure_delay": 240}, headers=auth).json()
    early = client.post(url, json={"departure_delay": 0}, headers=auth).json()
    assert late["arrival"]["mode"] == "live: departure delay"
    assert late["arrival"]["expected_minutes"] >= early["arrival"]["expected_minutes"]
    inbound = client.post(url, json={"inbound_arrival_delay": 90}, headers=auth).json()
    assert inbound["departure"]["mode"] == "live: inbound aircraft delay"
    values = list(inbound["departure"]["p"].values())
    assert values == sorted(values, reverse=True)  # the curve never rises with the threshold
    assert client.post(url, json={"departure_delay": 99999}, headers=auth).status_code == 422
    assert client.post("/api/v1/risk/flights/G9999_202611210000/predict", json={}, headers=auth).status_code == 404
    assert client.post(url, json={}).status_code == 401
