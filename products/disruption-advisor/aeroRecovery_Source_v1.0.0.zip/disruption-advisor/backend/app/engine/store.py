"""Read-only access to the operating picture (``<data_dir>/ops/*.parquet``) through an in-memory DuckDB.

The window is small (thousands of flights, ~300k passenger-segments), so the tables are loaded once at start-up
and queried with SQL. Every query reads only the columns it needs.
"""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import duckdb
import numpy as np

from app import flight_edits, sample_data
from app.ml import live_delay
from app.ml.live_delay import LiveModels
from app.ml.reward_pref import RewardModel

TABLES = ("flights", "pax_segments", "customers", "aircraft", "mct", "airports", "booking_classes")
RISK_TABLES = ("flight_risk", "connection_risk")  # phase 2 (ingest stage 3); optional so older data still loads


@dataclass(frozen=True)
class Leg:
    flight_id: str
    flight_number: str
    airline: str
    tail: str
    origin: str
    destination: str
    std: datetime
    sta: datetime
    capacity: int
    booked_seats: int
    booked_pax: int
    aircraft_model: str
    capacity_source: str

    @property
    def block_minutes(self) -> int:
        return int((self.sta - self.std).total_seconds() // 60)

    @property
    def available_seats(self) -> int:
        return max(self.capacity - self.booked_seats, 0)


@dataclass(frozen=True)
class CrewHeadroom:
    minutes: int  # max FDP - planned FDP of the tightest crew member
    crew_type: str | None  # CP captain, FO first officer, CC/CS cabin crew, ...
    source: str  # "roster" (this flight's crew) or "estimated" (the flight number's history)
    flights: int = 1  # rostered flights behind an estimate


LEG_COLUMNS = (
    "flight_id, flight_number, airline, tail, origin, destination, std, sta, capacity, booked_seats, "
    "booked_pax, aircraft_model, capacity_source"
)


class OpsStore:
    """Loads the ops Parquet tables into memory; each call uses its own cursor (thread-safe)."""

    def __init__(self, ops_dir: Path, test_dir: Path | None = None) -> None:
        self.ops_dir = ops_dir
        self.test_dir = test_dir
        self._con = duckdb.connect(":memory:")
        self._lock = threading.Lock()
        for table in TABLES:
            self._con.execute(f"CREATE TABLE {table} AS SELECT * FROM read_parquet('{ops_dir / table}.parquet')")
        self.test_version = self._add_test_data(test_dir)
        self.flights_edited = flight_edits.apply(self._con, test_dir)  # evaluator edits of existing flights
        self._con.execute("CREATE INDEX idx_pax_flight ON pax_segments (flight_id)")
        self._con.execute("CREATE INDEX idx_pax_pnr ON pax_segments (pnr)")
        self.has_risk = all((ops_dir / f"{t}.parquet").exists() for t in RISK_TABLES)
        if self.has_risk:
            for table in RISK_TABLES:
                self._con.execute(f"CREATE TABLE {table} AS SELECT * FROM read_parquet('{ops_dir / table}.parquet')")
            self._add_test_data(test_dir, sample_data.RISK_TABLES)
            flight_edits.apply_risk(self._con, test_dir)  # edited flights' re-scored 7-day risk
            self._con.execute("CREATE INDEX idx_conn_in ON connection_risk (inbound_flight_id)")
        card = ops_dir / "model_card.json"
        self.model_card: dict[str, Any] = json.loads(card.read_text()) if card.exists() else {}
        self.live_models = LiveModels.load(ops_dir)  # live departure/arrival models (ADR 0014); None = planning only
        window: tuple[list[str], np.ndarray] = (
            live_delay.window_matrix(ops_dir) if self.live_models else ([], np.zeros((0, 0)))
        )
        self.window_ids, self.window_x = window
        self.reward_model = RewardModel.load(ops_dir)  # phase 5 preference model; None = proxy rules
        cascade = ops_dir / "cascade_check.json"
        self.cascade_check: dict[str, Any] = json.loads(cascade.read_text()) if cascade.exists() else {}
        week = ops_dir / "last_week.json"
        self.last_week: dict[str, Any] = json.loads(week.read_text()) if week.exists() else {}
        report = ops_dir / "ingest_report.json"
        self.report: dict[str, Any] = json.loads(report.read_text()) if report.exists() else {}
        # Build PAX_COLUMNS dynamically: columns added in later ingest versions use NULL AS <col> fallback.
        _pax_cols = {r["column_name"] for r in self.query("DESCRIBE pax_segments")}
        _cust_cols = {r["column_name"] for r in self.query("DESCRIBE customers")}
        _pax_optional = (
            "family_account_synthetic",
            "family_head_synthetic",
            "family_tier_synthetic",
            "booking_class_level",
        )
        _cust_optional = ("loyalty_priority", "loyalty_id_synthetic", "available_points_synthetic")
        _family_sel = ", ".join(f"p.{c}" if c in _pax_cols else f"NULL AS {c}" for c in _pax_optional)
        _loyalty_sel = ", ".join(f"c.{c}" if c in _cust_cols else f"NULL AS {c}" for c in _cust_optional)
        self.PAX_COLUMNS = (
            "p.flight_id, p.pnr, p.customer_key, p.pax_type, p.origin, p.destination, "
            "p.dep_utc, p.booking_code, p.revenue_type, p.fare_family_synthetic, p.fare, p.ancillaries, "
            "p.baggage_kg, p.has_meal, p.has_seat, p.pnr_size, p.adults, p.children, p.infants, p.ssr_code, "
            "p.ssr_source, p.sales_channel, p.passenger_id, "
            "p.passport_number_synthetic, p.national_id_synthetic, p.identity_rule, "
            f"{_family_sel}, "
            f"c.is_loyalty_member, c.loyalty_tier_synthetic, {_loyalty_sel}, "
            "c.travel_frequency_band, c.flown_segments_12m, c.ambiguous_common_name"
        )
        # Connections the airline sells (fares list, X/hub/Y), for rebooking through the hub (gap 3)
        sold = ops_dir / "sold_connections.parquet"
        self.sold_connections: set[tuple[str, str, str]] = (
            {(o, h, d) for o, h, d in self._con.execute(f"SELECT origin, hub, destination FROM '{sold}'").fetchall()}
            if sold.exists()
            else set()
        )
        # Crew FDP headroom: rostered flights, and per flight number from its rostered history
        self.crew_by_flight: dict[str, CrewHeadroom] = {}
        self.crew_by_number: dict[str, CrewHeadroom] = {}
        crew, est = ops_dir / "crew_flights.parquet", ops_dir / "crew_fdp_estimates.parquet"
        if crew.exists():
            for fid, minutes, tightest in self._con.execute(
                f"SELECT flight_id, headroom_minutes, tightest FROM '{crew}'"
            ).fetchall():
                self.crew_by_flight[fid] = CrewHeadroom(int(minutes), tightest, "roster")
        if est.exists():
            for number, minutes, tightest, n in self._con.execute(
                f"SELECT flight_number, headroom_p10, tightest, flights FROM '{est}'"
            ).fetchall():
                self.crew_by_number[number] = CrewHeadroom(int(minutes), tightest, "estimated", int(n))
        fdp = ops_dir / "crew_fdp.json"
        self.crew_fdp: dict[str, Any] = json.loads(fdp.read_text()) if fdp.exists() else {}

    def crew_headroom(self, leg: Leg) -> CrewHeadroom | None:
        """Minutes the duty of ``leg``'s tightest crew member can still be extended before the maximum FDP: the
        roster when the flight has one, else the 10th percentile of the same flight number's rostered history."""
        return self.crew_by_flight.get(leg.flight_id) or self.crew_by_number.get(leg.flight_number)

    def _add_test_data(self, test_dir: Path | None, tables: tuple[str, ...] = sample_data.TABLES) -> int | None:
        """Append the uploaded test flights (app/sample_data.py) to the in-memory tables; the Parquet is untouched."""
        stamp = sample_data.version(test_dir) if test_dir else None
        if test_dir is None or stamp is None:
            return None
        for table in tables:
            path = test_dir / f"{table}.parquet"
            if path.exists():
                # Only the columns the real table has; columns it lacks are left out, ones the sheet lacks stay NULL.
                have = {
                    r[0]
                    for r in self._con.execute(
                        f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table}'"
                    ).fetchall()
                }
                cols = [
                    r[0]
                    for r in self._con.execute(f"DESCRIBE SELECT * FROM read_parquet('{path}')").fetchall()
                    if r[0] in have
                ]
                listing = ", ".join(f'"{c}"' for c in cols)
                self._con.execute(f"INSERT INTO {table} BY NAME SELECT {listing} FROM read_parquet('{path}')")
        return stamp

    def query(self, sql: str, params: list[Any] | None = None) -> list[dict[str, Any]]:
        cur = self._con.cursor()
        try:
            rel = cur.execute(sql, params or [])
            cols = [d[0] for d in rel.description]
            return [dict(zip(cols, row, strict=True)) for row in rel.fetchall()]
        finally:
            cur.close()

    def arrow(self, sql: str, params: list[Any] | None = None) -> Any:
        """A query result as an Arrow table (for re-scoring edited flights)."""
        cur = self._con.cursor()
        try:
            return cur.execute(sql, params or []).to_arrow_table()
        finally:
            cur.close()

    def ready(self) -> bool:
        return bool(self.query("SELECT count(*) AS n FROM flights")[0]["n"])

    # --- flights -------------------------------------------------------------------------------------------
    @staticmethod
    def _leg(row: dict[str, Any]) -> Leg:
        return Leg(**{k: row[k] for k in LEG_COLUMNS.split(", ")})

    def leg(self, flight_id: str) -> Leg | None:
        rows = self.query(f"SELECT {LEG_COLUMNS} FROM flights WHERE flight_id = ? AND sta IS NOT NULL", [flight_id])
        return self._leg(rows[0]) if rows else None

    def tail_legs(self, tail: str, start: datetime, end: datetime) -> list[Leg]:
        rows = self.query(
            f"SELECT {LEG_COLUMNS} FROM flights "
            "WHERE tail = ? AND std >= ? AND std < ? AND sta IS NOT NULL ORDER BY std",
            [tail, start, end],
        )
        return [self._leg(r) for r in rows]

    def search_flights(self, text: str, day: str | None, limit: int) -> list[dict[str, Any]]:
        like = f"%{text.upper()}%"
        sql = (
            f"SELECT {LEG_COLUMNS} FROM flights WHERE sta IS NOT NULL AND "
            "(flight_number LIKE ? OR origin LIKE ? OR destination LIKE ? OR tail LIKE ?)"
        )
        params: list[Any] = [like, like, like, like]
        if day:
            sql += " AND CAST(std AS DATE) = CAST(? AS DATE)"
            params.append(day)
        return self.query(sql + " ORDER BY std LIMIT ?", [*params, limit])

    def tails_at_station(
        self, station: str, earliest: datetime, latest: datetime, model_seats: int, exclude: str
    ) -> list[str]:
        """Tails with the same seat count that depart ``station`` between earliest and latest (swap candidates)."""
        rows = self.query(
            """SELECT DISTINCT tail FROM flights
               WHERE origin = ? AND std BETWEEN ? AND ? AND tail <> ? AND capacity = ? AND sta IS NOT NULL
               ORDER BY tail""",
            [station, earliest, latest, exclude, model_seats],
        )
        return [r["tail"] for r in rows]

    def alternatives(
        self, origin: str, destination: str, after: datetime, before: datetime, exclude: list[str]
    ) -> list[Leg]:
        rows = self.query(
            f"""SELECT {LEG_COLUMNS} FROM flights
                WHERE origin = ? AND destination = ? AND std > ? AND std <= ? AND sta IS NOT NULL
                  AND NOT list_contains(?, flight_id)
                ORDER BY std""",
            [origin, destination, after, before, exclude],
        )
        return [self._leg(r) for r in rows]

    def via_hub(
        self,
        origin: str,
        destination: str,
        hub: str,
        after: datetime,
        before: datetime,
        exclude: list[str],
        min_connection: timedelta,
        max_connection: timedelta,
        limit: int = 12,
    ) -> list[tuple[Leg, Leg]]:
        """Two-flight itineraries origin -> hub -> destination that the airline sells as a connection (fares list),
        leaving after ``after``, arriving by ``before``, with a connection between the minimum (MCT) and maximum
        time. Earliest arrival first."""
        if origin == hub or destination == hub or (origin, hub, destination) not in self.sold_connections:
            return []
        rows = self.query(
            f"""SELECT {", ".join("a." + c.strip() for c in LEG_COLUMNS.split(","))},
                       {", ".join("b." + c.strip() + " AS b_" + c.strip() for c in LEG_COLUMNS.split(","))}
                FROM flights a JOIN flights b
                  ON b.origin = a.destination AND b.std >= a.sta + ? AND b.std <= a.sta + ?
                WHERE a.origin = ? AND a.destination = ? AND b.destination = ?
                  AND a.std > ? AND b.sta <= ? AND a.sta IS NOT NULL AND b.sta IS NOT NULL
                  AND NOT list_contains(?, a.flight_id) AND NOT list_contains(?, b.flight_id)
                ORDER BY b.sta, a.std LIMIT ?""",
            [min_connection, max_connection, origin, hub, destination, after, before, exclude, exclude, limit],
        )
        cols = [c.strip() for c in LEG_COLUMNS.split(",")]
        return [(self._leg({c: r[c] for c in cols}), self._leg({c: r[f"b_{c}"] for c in cols})) for r in rows]

    # --- passengers ----------------------------------------------------------------------------------------

    def passengers_on(self, flight_ids: list[str]) -> list[dict[str, Any]]:
        if not flight_ids:
            return []
        return self.query(
            f"""SELECT {self.PAX_COLUMNS} FROM pax_segments p LEFT JOIN customers c USING (customer_key)
                WHERE list_contains(?, p.flight_id) ORDER BY p.pnr, p.customer_key""",
            [flight_ids],
        )

    def onward_segments(self, pnrs: list[str], after: datetime, until: datetime) -> list[dict[str, Any]]:
        """Later segments of the same PNRs (journey continuation), joined to their flight times."""
        if not pnrs:
            return []
        return self.query(
            """SELECT p.pnr, p.customer_key, p.flight_id, p.origin, p.destination, f.std, f.sta, f.flight_number
               FROM pax_segments p JOIN flights f USING (flight_id)
               WHERE list_contains(?, p.pnr) AND f.std > ? AND f.std <= ? ORDER BY f.std""",
            [pnrs, after, until],
        )

    def mct_minutes(self, origin: str, hub: str, destination: str, default: int) -> int:
        rows = self.query(
            "SELECT min_minutes FROM mct WHERE origin = ? AND hub = ? AND destination = ?", [origin, hub, destination]
        )
        return int(rows[0]["min_minutes"]) if rows else default

    def airport_tz(self) -> dict[str, str]:
        return {r["iata"]: r["tz"] for r in self.query("SELECT iata, tz FROM airports")}

    def country_of(self, iata: str) -> str | None:
        rows = self.query("SELECT country FROM airports WHERE iata = ?", [iata])
        return rows[0]["country"] if rows else None


_store: OpsStore | None = None
_store_lock = threading.Lock()


def get_store(ops_dir: Path) -> OpsStore:
    """Process-wide store, loaded on first use."""
    global _store
    with _store_lock:
        if _store is None or _store.ops_dir != ops_dir:
            _store = OpsStore(ops_dir)
        return _store
